from .scripts_collector import *
from .urls_collector import *
