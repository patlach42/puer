from .runserver import RunServer

__scripts__ = {
    "runserver": RunServer
}
