from .run import RunServer

scripts = {
    "run": RunServer
}
